# Semantic Backend - Docker Setup

برای اجرای بک‌اند این پروژه روی سیستم خودت فقط نیاز به Docker و Docker Compose داری.

## پیش‌نیازها

- [Docker](https://docs.docker.com/get-docker/)
- [Docker Compose](https://docs.docker.com/compose/install/)

## مراحل اجرا

1. وارد پوشه پروژه شو:
```bash
cd semantic-backend-deploy