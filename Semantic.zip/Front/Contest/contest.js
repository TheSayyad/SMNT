document.addEventListener("DOMContentLoaded", function () {
  const arrBtn = document.querySelector(".arrbtn");
  const mainDiv = document.querySelector(".main");
  const sections = document.querySelectorAll(".section");
  const sidebar = document.querySelector(".sidebar");
  const sidebarButtons = document.querySelectorAll(".sidebar-btn");
  const semanticBtn = document.getElementById("Semantic");
  const toggleButton = document.querySelector(".sidebar-toggle");
  const overlay = document.createElement("div");

  // Create and style the overlay
  overlay.classList.add("overlay");
  document.body.appendChild(overlay);

  // Function to highlight the active sidebar button
  function highlightButton(button) {
    sidebarButtons.forEach(
      (btn) => (btn.style.backgroundColor = "transparent")
    );
    button.style.backgroundColor = "#e7327c";
  }

  // Function to show a specific section
  function showSection(sectionToShow) {
    sections.forEach((section) => {
      section.style.opacity = "0";
      setTimeout(() => (section.style.display = "none"), 500);
    });
    setTimeout(() => {
      sectionToShow.style.display = "flex";
      setTimeout(() => (sectionToShow.style.opacity = "1"), 10);
    }, 500);
  }

  // Function to show the main section
  function showMainSection() {
    sections.forEach((section) => {
      section.style.opacity = "0";
      setTimeout(() => (section.style.display = "none"), 500);
    });
    setTimeout(() => {
      mainDiv.style.display = "block";
      sidebar.style.display = "none";
      setTimeout(() => (mainDiv.style.opacity = "1"), 10);
    }, 500);
  }

  // Function to open the sidebar
  function openSidebar() {
    sidebar.style.transform = "translateX(-50%)";
    overlay.style.display = "block";
    setTimeout(() => (overlay.style.opacity = "1"), 10);
  }

  // Function to close the sidebar
  function closeSidebar() {
    sidebar.style.transform = "translateX(100%)";
    overlay.style.opacity = "0";
    setTimeout(() => (overlay.style.display = "none"), 300);
  }

  // Event listener for the toggle button to open the sidebar
  toggleButton.addEventListener("click", openSidebar);

  // Event listener for the overlay to close the sidebar
  overlay.addEventListener("click", closeSidebar);

  // Event listener for the Semantic button to return to the main section
  semanticBtn.addEventListener("click", function () {
    closeSidebar();
    showMainSection();
  });

  // Event listeners for sidebar buttons to show specific sections
  sidebarButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const sectionClass = button.classList[1].replace("-btn", "");
      showSection(document.querySelector(`.${sectionClass}`));
      highlightButton(button);
      closeSidebar();
    });
  });

  // Event listener for the "arrbtn" button to switch to the contest section
  arrBtn.addEventListener("click", function () {
    mainDiv.style.opacity = "0";
    setTimeout(() => {
      mainDiv.style.display = "none";
      sidebar.style.display = "flex";
      showSection(document.querySelector(".contest"));
      highlightButton(document.querySelector(".contest-btn"));
    }, 500);
  });

  // FAQ toggle functionality
  const faqItems = document.querySelectorAll(".faq-item");
  faqItems.forEach((item) => {
    item.querySelector(".faq-question").addEventListener("click", () => {
      item.classList.toggle("active");
      const icon = item.querySelector(".faq-icon");
      icon.textContent = item.classList.contains("active") ? "-" : "+";
    });
  });

  // Video popup functionality
  document.querySelectorAll(".video-thumbnail").forEach((item) => {
    item.addEventListener("click", function () {
      let videoSrc = this.getAttribute("data-video");
      let popup = document.getElementById("popup");
      let popupVideo = document.getElementById("popupVideo");
      popupVideo.src = videoSrc;
      popup.style.display = "flex";
      popupVideo.play();
    });
  });

  // Close video popup
  function closePopup() {
    let popup = document.getElementById("popup");
    let popupVideo = document.getElementById("popupVideo");
    popupVideo.pause();
    popupVideo.src = "";
    popup.style.display = "none";
  }

  // Image modal functionality
  const images = document.querySelectorAll(".gallery-container img");
  const modal = document.getElementById("imageModal");
  const modalImg = modal.querySelector("img");

  images.forEach((img) => {
    img.addEventListener("click", () => {
      modal.style.display = "flex";
      modalImg.src = img.src;
    });
  });

  modal.addEventListener("click", () => {
    modal.style.display = "none";
    modalImg.src = "";
  });
});
