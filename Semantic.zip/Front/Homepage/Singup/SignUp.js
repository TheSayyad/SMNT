// متغیرهای全局
let currentStep = 1;
const players = [];

// عناصر DOM
const popupOverlay = document.getElementById("popupOverlay");
const showPopupBtn = document.getElementById("showPopupBtn");
const backBtn = document.getElementById("backBtn");
const nextBtn1 = document.getElementById("nextBtn1");
const addPlayerBtn = document.getElementById("addPlayerBtn");
const submitBtn = document.getElementById("submitBtn");
const homeBtn = document.getElementById("homeBtn");
const step1 = document.getElementById("step1");
const step2 = document.getElementById("step2");
const step3 = document.getElementById("step3");
const teamInfoReview = document.getElementById("teamInfoReview");
const playerList = document.getElementById("playerList");
const addedPlayersHeader = document.getElementById("addedPlayersHeader");

// نمایش پاپ آپ
showPopupBtn.addEventListener("click", () => {
  popupOverlay.style.display = "flex";
  document.body.style.overflow = "hidden";
});

// رفتن به مرحله بعدی با انیمیشن
nextBtn1.addEventListener("click", () => {
  const university = document.getElementById("university").value;
  const teamName = document.getElementById("teamName").value;

  if (!university || !teamName) {
    showTempMessage("لطفاً تمام فیلدهای ضروری را پر کنید", "error");
    return;
  }

  // نمایش اطلاعات تیم در مرحله 2
  teamInfoReview.innerHTML = `
                <p><strong>دانشگاه:</strong> ${university}</p>
                <p><strong>نام تیم:</strong> ${teamName}</p>
            `;

  // تغییر به مرحله 2 با انیمیشن
  step1.classList.remove("active");
  setTimeout(() => {
    step2.classList.add("active");
    backBtn.style.display = "block";
    currentStep = 2;
    // اسکرول به بالای فرم
    document.querySelector(".form-side").scrollTo(0, 0);
  }, 300);
});

// بازگشت به مرحله قبلی با انیمیشن
backBtn.addEventListener("click", () => {
  if (currentStep === 2) {
    step2.classList.remove("active");
    setTimeout(() => {
      step1.classList.add("active");
      backBtn.style.display = "none";
      currentStep = 1;
    }, 300);
  } else if (currentStep === 3) {
    step3.classList.remove("active");
    setTimeout(() => {
      step2.classList.add("active");
      currentStep = 2;
      backBtn.style.display = "block";
    }, 300);
  }
});

// اضافه کردن بازیکن جدید
addPlayerBtn.addEventListener("click", () => {
  const firstName = document.getElementById("firstName").value;
  const lastName = document.getElementById("lastName").value;
  const studentId = document.getElementById("studentId").value;
  const email = document.getElementById("email").value;
  const educationLevel = document.getElementById("educationLevel").value;
  const phone = document.getElementById("phone").value;
  const nationalCode = document.getElementById("nationalCode").value;

  if (
    !firstName ||
    !lastName ||
    !studentId ||
    !email ||
    !educationLevel ||
    !phone ||
    !nationalCode
  ) {
    showTempMessage("لطفاً تمام فیلدهای بازیکن را پر کنید", "error");
    return;
  }

  // ایجاد شیء بازیکن
  const player = {
    id: Date.now(), // یک شناسه منحصر به فرد برای بازیکن
    firstName,
    lastName,
    studentId,
    email,
    educationLevel,
    phone,
    nationalCode,
  };

  // اضافه کردن به لیست بازیکنان
  players.push(player);

  // نمایش بازیکن در لیست
  addPlayerToDOM(player);

  // نمایش هدر بازیکنان اضافه شده اگر وجود دارند
  if (players.length > 0) {
    addedPlayersHeader.style.display = "block";
  }

  // پاک کردن فرم
  resetPlayerForm();

  // نمایش پیام با انیمیشن
  showTempMessage("بازیکن با موفقیت اضافه شد", "success");
});

// تابع برای اضافه کردن بازیکن به DOM
function addPlayerToDOM(player) {
  // اضافه کردن به لیست بازیکنان
  const playerItem = document.createElement("div");
  playerItem.className = "player-item fade-in";
  playerItem.dataset.id = player.id;
  playerItem.innerHTML = `
                <button class="remove-player" onclick="removePlayer(${player.id})">×</button>
                <p><strong>نام:</strong> ${player.firstName} ${player.lastName}</p>
                <p><strong>شماره دانشجویی:</strong> ${player.studentId}</p>
                <p><strong>مقطع:</strong> ${player.educationLevel}</p>
            `;
  playerList.appendChild(playerItem);

  // اضافه کردن به تگ‌های بالای صفحه
  const playerTag = document.createElement("div");
  playerTag.className = "player-tag fade-in";
  playerTag.dataset.id = player.id;
  playerTag.innerHTML = `
                <span class="remove-tag" onclick="removePlayer(${player.id})">×</span>
                ${player.firstName} ${player.lastName}
            `;
  addedPlayersHeader.appendChild(playerTag);
}

// تابع برای حذف بازیکن
window.removePlayer = function (playerId) {
  // حذف از آرایه
  const playerIndex = players.findIndex((p) => p.id === playerId);
  if (playerIndex !== -1) {
    players.splice(playerIndex, 1);
  }

  // حذف از DOM
  document.querySelector(`.player-item[data-id="${playerId}"]`)?.remove();
  document.querySelector(`.player-tag[data-id="${playerId}"]`)?.remove();

  // مخفی کردن هدر اگر بازیکنی وجود ندارد
  if (players.length === 0) {
    addedPlayersHeader.style.display = "none";
  }

  showTempMessage("بازیکن حذف شد", "warning");
};

// تابع برای نمایش پیام موقت
function showTempMessage(message, type = "success") {
  const tempMsg = document.createElement("div");
  tempMsg.textContent = message;
  tempMsg.style.position = "fixed";
  tempMsg.style.bottom = "30px";
  tempMsg.style.left = "50%";
  tempMsg.style.transform = "translateX(-50%)";
  tempMsg.style.padding = "12px 20px";
  tempMsg.style.borderRadius = "6px";
  tempMsg.style.zIndex = "1001";
  tempMsg.style.animation = "fadeIn 0.3s ease forwards";
  tempMsg.style.fontWeight = "500";
  tempMsg.style.boxShadow = "0 4px 12px rgba(0, 0, 0, 0.3)";

  // رنگ‌بندی بر اساس نوع پیام
  if (type === "success") {
    tempMsg.style.backgroundColor = "#4CAF50";
    tempMsg.style.color = "white";
  } else if (type === "error") {
    tempMsg.style.backgroundColor = "#f44336";
    tempMsg.style.color = "white";
  } else if (type === "warning") {
    tempMsg.style.backgroundColor = "#FF9800";
    tempMsg.style.color = "black";
  }

  document.body.appendChild(tempMsg);

  setTimeout(() => {
    tempMsg.style.animation = "fadeIn 0.3s ease reverse forwards";
    setTimeout(() => tempMsg.remove(), 300);
  }, 2500);
}

// تابع ریست فرم بازیکن
function resetPlayerForm() {
  document.getElementById("firstName").value = "";
  document.getElementById("lastName").value = "";
  document.getElementById("studentId").value = "";
  document.getElementById("email").value = "";
  document.getElementById("educationLevel").value = "";
  document.getElementById("phone").value = "";
  document.getElementById("nationalCode").value = "";
}

// ثبت نهایی و رفتن به صفحه تأیید
submitBtn.addEventListener("click", () => {
  if (players.length === 0) {
    showTempMessage("لطفاً حداقل یک بازیکن اضافه کنید", "error");
    return;
  }

  const university = document.getElementById("university").value;
  const teamName = document.getElementById("teamName").value;

  // در اینجا می‌توانید داده‌ها را به سرور ارسال کنید
  const formData = {
    university,
    teamName,
    players,
  };

  console.log("داده‌های فرم:", formData);

  // رفتن به صفحه تأیید با انیمیشن
  step2.classList.remove("active");
  setTimeout(() => {
    step3.classList.add("active");
    currentStep = 3;
    backBtn.style.display = "none";
    // اسکرول به بالای صفحه تأیید
    document.querySelector(".form-side").scrollTo(0, 0);
  }, 300);
});

// بازگشت به صفحه اصلی
homeBtn.addEventListener("click", () => {
  popupOverlay.style.display = "none";
  document.body.style.overflow = "auto";
  resetForm();
});

// تابع ریست فرم کامل
function resetForm() {
  document.getElementById("university").value = "";
  document.getElementById("teamName").value = "";
  resetPlayerForm();

  players.length = 0;
  playerList.innerHTML = "";
  addedPlayersHeader.innerHTML =
    '<h3 style="width: 100%; margin: 0 0 12px 0; font-size: 15px; color: var(--yellow);">بازیکنان اضافه شده:</h3>';
  addedPlayersHeader.style.display = "none";

  step3.classList.remove("active");
  step1.classList.add("active");
  backBtn.style.display = "none";
  currentStep = 1;
}
